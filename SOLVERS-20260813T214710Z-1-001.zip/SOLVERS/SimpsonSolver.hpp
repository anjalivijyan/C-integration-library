#ifndef SIMPSONSOLVER_HPP
#define SIMPSONSOLVER_HPP

#include <cstddef>
#include "solver.hpp"

class SimpsonSolver : public Solver {
public:
    explicit SimpsonSolver(std::size_t nIntervals)
        : n(nIntervals % 2 == 0 ? nIntervals : nIntervals + 1) {}

    double integrate(const Function& f, double a, double b) const override {
        double h = (b - a) / static_cast<double>(n);
        double sum = f(a) + f(b);

        // odd indices: coefficient 4
        for (std::size_t i = 1; i < n; i += 2) {
            double x = a + h * static_cast<double>(i);
            sum += 4.0 * f(x);
        }
        // even indices: coefficient 2
        for (std::size_t i = 2; i < n; i += 2) {
            double x = a + h * static_cast<double>(i);
            sum += 2.0 * f(x);
        }
        return h * sum / 3.0;
    }

private:
    std::size_t n;
};

#endif // SIMPSONSOLVER_HPP
