#ifndef TRAPEZOIDSOLVER_HPP
#define TRAPEZOIDSOLVER_HPP

#include <cstddef>
#include "solver.hpp"

class TrapezoidSolver : public Solver {
public:
    explicit TrapezoidSolver(std::size_t nIntervals)
        : n(nIntervals) {}

    double integrate(const Function& f, double a, double b) const override {
        double h = (b - a) / static_cast<double>(n);
        double sum = 0.5 * (f(a) + f(b));
        for (std::size_t i = 1; i < n; ++i) {
            double x = a + h * static_cast<double>(i);
            sum += f(x);
        }
        return h * sum;
    }

private:
    std::size_t n;
};

#endif // TRAPEZOIDSOLVER_HPP
