#ifndef REPEATED1DSOLVER2D_HPP
#define REPEATED1DSOLVER2D_HPP

#include <memory>
#include <cstddef>

#include "solver2d.hpp"
#include "solver.hpp"          // 1D Solver
#include "../functions/function.hpp"  // Function & Function2D

class Repeated1DSolver2D : public Solver2D {
public:
    // innerSolver is the 1D solver used for integration over y
    Repeated1DSolver2D(std::unique_ptr<Solver> innerSolver,
                       std::size_t nOuter)
        : inner_(std::move(innerSolver)),
          nOuterPoints_(nOuter) {}

    double integrate(const Function2D& f,
                     double ax, double bx,
                     double ay, double by) const override {
        // Approximate ∫_ax^bx [ ∫_ay^by f(x,y) dy ] dx
        double hOuter = (bx - ax) / static_cast<double>(nOuterPoints_);
        double result = 0.0;

        for (std::size_t i = 0; i <= nOuterPoints_; ++i) {
            double x = ax + i * hOuter;

            // Inner function g_x(y) = f(x,y) as a 1D Function
            class InnerFunction : public Function {
            public:
                InnerFunction(const Function2D& f2d, double xVal)
                    : f2d_(f2d), x_(xVal) {}

                double operator()(double y) const override {
                    return f2d_(x_, y);
                }

            private:
                const Function2D& f2d_;
                double x_;
            };

            InnerFunction gx(f, x);
            double innerIntegral = inner_->integrate(gx, ay, by);

            // Composite trapezoid in x
            if (i == 0 || i == nOuterPoints_) {
                result += 0.5 * innerIntegral;
            } else {
                result += innerIntegral;
            }
        }

        return hOuter * result;
    }

private:
    std::unique_ptr<Solver> inner_;
    std::size_t nOuterPoints_;
};

#endif // REPEATED1DSOLVER2D_HPP
