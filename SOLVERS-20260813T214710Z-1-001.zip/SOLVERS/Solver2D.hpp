#ifndef SOLVER2D_HPP
#define SOLVER2D_HPP

#include "../functions/function.hpp"   // for Function2D

class Solver2D {
public:
    virtual ~Solver2D() = default;

    virtual double integrate(const Function2D& f,
                             double ax, double bx,
                             double ay, double by) const = 0;
};

#endif // SOLVER2D_HPP
