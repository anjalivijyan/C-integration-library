#ifndef GAUSSIANSOLVER_HPP
#define GAUSSIANSOLVER_HPP

#include <cstddef>
#include "solver.hpp"

class GaussianSolver : public Solver {
public:
    explicit GaussianSolver(std::size_t nIntervals)
        : n(nIntervals) {}

    double integrate(const Function& f, double a, double b) const override {
        // 2-point Gauss-Legendre on each subinterval
        const double x1 = -1.0 / std::sqrt(3.0);
        const double x2 =  1.0 / std::sqrt(3.0);
        const double w1 = 1.0;
        const double w2 = 1.0;

        double h = (b - a) / static_cast<double>(n);
        double result = 0.0;

        for (std::size_t i = 0; i < n; ++i) {
            double left  = a + h * static_cast<double>(i);
            double right = left + h;
            double mid   = 0.5 * (left + right);
            double half  = 0.5 * h;

            double t1 = mid + half * x1;
            double t2 = mid + half * x2;

            result += half * (w1 * f(t1) + w2 * f(t2));
        }
        return result;
    }

private:
    std::size_t n;
};

#endif // GAUSSIANSOLVER_HPP
