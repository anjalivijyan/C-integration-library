#ifndef SOLVER_HPP
#define SOLVER_HPP

#include "../functions/function.hpp"

class Solver {
public:
    virtual ~Solver() = default;

    // approximate integral of f on [a,b]
    virtual double integrate(const Function& f, double a, double b) const = 0;
};

#endif // SOLVER_HPP
 