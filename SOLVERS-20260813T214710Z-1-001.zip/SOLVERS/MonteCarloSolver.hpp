#ifndef MONTECARLOSOLVER_HPP
#define MONTECARLOSOLVER_HPP

#include <cstddef>
#include <random>
#include "solver.hpp"

class MonteCarloSolver : public Solver {
public:
    explicit MonteCarloSolver(std::size_t nSamples)
        : n(nSamples) {}

    double integrate(const Function& f, double a, double b) const override {
        std::mt19937 gen(42); // seed fixe pour résultats reproductibles
        std::uniform_real_distribution<double> dist(a, b);

        double sum = 0.0;
        for (std::size_t i = 0; i < n; ++i) {
            double x = dist(gen);
            sum += f(x);
        }

        return (b - a) * sum / static_cast<double>(n);
    }

private:
    std::size_t n;
};

#endif // MONTECARLOSOLVER_HPP
