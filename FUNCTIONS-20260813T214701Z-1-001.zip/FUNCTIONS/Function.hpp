#ifndef FUNCTION_HPP
#define FUNCTION_HPP

#include <cmath>

// ===== 1D functions =====

class Function {
public:
    virtual ~Function() = default;
    virtual double operator()(double x) const = 0;
};

class XSquaredCos : public Function {
public:
    double operator()(double x) const override {
        return x * x * std::cos(x);
    }
};

class XPowerTen : public Function {
public:
    double operator()(double x) const override {
        return std::pow(x, 10.0);
    }
};

class InvSqrt : public Function {
public:
    double operator()(double x) const override {
        return 1.0 / std::sqrt(x);
    }
};

class LogX : public Function {
public:
    double operator()(double x) const override {
        return std::log(x);
    }
};

// ===== 2D functions =====

class Function2D {
public:
    virtual ~Function2D() = default;
    virtual double operator()(double x, double y) const = 0;
};

// Example: f(x,y) = x * y
class XYFunction : public Function2D {
public:
    double operator()(double x, double y) const override {
        return x * y;
    }
};

// Example: f(x,y) = sin(pi x) * sin(pi y)
class SinPiSinPi : public Function2D {
public:
    double operator()(double x, double y) const override {
        const double pi = 3.14159265358979323846;
        return std::sin(pi * x) * std::sin(pi * y);
    }
};

#endif // FUNCTION_HPP
